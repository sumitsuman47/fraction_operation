    import Foundation
    
    struct ImproperFraction {
        var numerator: Int
        var denominator: Int
        
        // convert into a b/c from ((a*c)+b)/c
        func creatMixNumber() -> MixedNumber {
            let whole = numerator / denominator
            let num = numerator % denominator
            return MixedNumber(whole: whole, numerator: num, denominator: denominator)
        }
    }
    
    struct MixedNumber {
        var whole: Int = 0
        var numerator: Int
        var denominator: Int {
            didSet  {
                if self.denominator == 0 {
                    self.denominator = 1
                }
            }
        }
        
        // convert a b/c into ((a*c)+b)/c
        func improperFraction() -> ImproperFraction  {
            let fraction = ImproperFraction(
                numerator: ((self.whole * self.denominator) + self.numerator),
                denominator: self.denominator
            )
            return fraction
        }
        
    }
    
    //Greatest common divisor
    func gcd(numerator: Int, denominator: Int) -> Int {
      var a = 0
      var b = max(numerator, denominator)
      var r = min(numerator, denominator)

      while r != 0 {
        a = b
        b = r
        r = a % b
      }
      return b
    }
    
    //Reduce the fraction
    func reduced(numerator: Int, denominator: Int) -> ImproperFraction {
        let factor = gcd(numerator: numerator, denominator: denominator)
        return ImproperFraction(numerator: numerator / factor, denominator: denominator / factor)
        
    }
    
    //Addition
    func addition(first: ImproperFraction, second: ImproperFraction) -> ImproperFraction {
        // Formula: a/b + c/d = (ad + bc) / bd
        let simplifiedNumerator = ((first.numerator * second.denominator) + (first.denominator * second.numerator))
        let simplifiedDenominator = (first.denominator * second.denominator)
        return reduced(numerator: simplifiedNumerator, denominator: simplifiedDenominator)
    }
    
    //Subtraction
    func subtract(first: ImproperFraction, second: ImproperFraction) -> ImproperFraction {
       //Formula: a/b - c/d = (ad - bc) / bd
        let simplifiedNumerator = ((first.numerator * second.denominator) - (first.denominator * second.numerator))
        let simplifiedDenominator = (first.denominator * second.denominator)
        return reduced(numerator: simplifiedNumerator, denominator: simplifiedDenominator)
    }
    
    //Multiplication
    func multiplication(first: ImproperFraction, second: ImproperFraction) -> ImproperFraction {
        //Formula: a/b * c/d = ac / bd
        let simplifiedNumerator = (first.numerator * second.numerator)
        let simplifiedDenominator = (first.denominator * second.denominator)
        return reduced(numerator: simplifiedNumerator, denominator: simplifiedDenominator)
    }
    
    //Division
    func division(first: ImproperFraction, second: ImproperFraction) -> ImproperFraction {
       //Formula: a/b ÷ c/d = ad / bc
        let simplifiedNumerator = (first.numerator * second.denominator)
        let simplifiedDenominator = (first.denominator * second.numerator)
        return reduced(numerator: simplifiedNumerator, denominator: simplifiedDenominator)
    }
    
    
    
    let firstMixedNumber = MixedNumber(whole: 2, numerator: 1, denominator: 4)
    firstMixedNumber.improperFraction()
    print(firstMixedNumber.improperFraction())
    
    
    let secondMixedNumber = MixedNumber(whole: 1, numerator: 2, denominator: 6)
    secondMixedNumber.improperFraction()
    print(secondMixedNumber.improperFraction())
    
    let addFraction = addition(first: firstMixedNumber.improperFraction(), second: secondMixedNumber.improperFraction())
    let subtractFraction = subtract(first: firstMixedNumber.improperFraction(), second: secondMixedNumber.improperFraction())
    let multiplyFraction = multiplication(first: firstMixedNumber.improperFraction(), second: secondMixedNumber.improperFraction())
    let divideFraction = division(first: firstMixedNumber.improperFraction(), second: secondMixedNumber.improperFraction())
    
    print(addFraction)
    print(addFraction.creatMixNumber())
    
    print(subtractFraction)
    print(subtractFraction.creatMixNumber())
    
    print(multiplyFraction)
    print(multiplyFraction.creatMixNumber())

    print(divideFraction)
    print(divideFraction.creatMixNumber())
    
    
